import "./subnav.css";
function Sub() {
  return (
    <div class="parent">
      <nav class="subnav">
        <ul>
          <li>WomenEthnic</li>
          <li>WomenWestern</li>
          <li>Men</li>
          <li>Kids</li>
          <li>Home&Kitchen</li>
          <li>Beauty&Health</li>
          <li>Jewellery&Accessories</li>
          <li>Bag&Footwear</li>
          <li>Electronics</li>
        </ul>
      </nav>
    </div>
  );
}
export default Sub;
